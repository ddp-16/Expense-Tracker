import java.sql.*;
import java.util.HashMap;
import java.util.Map;
import javafx.stage.Stage;

public class IncomeExpenseTracker {
    private Connection conn;
    private int userId;

    public IncomeExpenseTracker(int userId) {
        conn = DatabaseConnection.getConnection();
        this.userId = userId;
    }

    public void addIncome(double amount, String description) {
        try {
            String query = "INSERT INTO income (user_id, amount, description, date) VALUES (?, ?, ?, CURDATE())";
            PreparedStatement ps = conn.prepareStatement(query);
            ps.setInt(1, userId);
            ps.setDouble(2, amount);
            ps.setString(3, description);
            ps.executeUpdate();
            System.out.println("Income added successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void addExpense(double amount, String description) {
        try {
            String query = "INSERT INTO expenses (user_id, amount, description, date) VALUES (?, ?, ?, CURDATE())";
            PreparedStatement ps = conn.prepareStatement(query);
            ps.setInt(1, userId);
            ps.setDouble(2, amount);
            ps.setString(3, description);
            ps.executeUpdate();
            System.out.println("Expense added successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void showSummary(Stage primaryStage) {
        try {
            // Query for total income
            String incomeQuery = "SELECT SUM(amount) FROM income WHERE user_id = ?";
            PreparedStatement psIncome = conn.prepareStatement(incomeQuery);
            psIncome.setInt(1, userId);
            ResultSet rsIncome = psIncome.executeQuery();

            double totalIncome = 0;
            if (rsIncome.next()) {
                totalIncome = rsIncome.getDouble(1);
            }

            // Query for expenses by category
            String expenseQuery = "SELECT description, SUM(amount) FROM expenses WHERE user_id = ? GROUP BY description";
            PreparedStatement psExpense = conn.prepareStatement(expenseQuery);
            psExpense.setInt(1, userId);
            ResultSet rsExpense = psExpense.executeQuery();

            Map<String, Double> expenseCategories = new HashMap<>();
            double totalExpense = 0;

            while (rsExpense.next()) {
                String category = rsExpense.getString(1);
                double amount = rsExpense.getDouble(2);
                expenseCategories.put(category, amount);  // Store expense breakdown by category
                totalExpense += amount;
            }

            // Output totals to the console (for debugging or reference)
            System.out.println("Total Income: " + totalIncome);
            System.out.println("Total Expense: " + totalExpense);
            for (Map.Entry<String, Double> entry : expenseCategories.entrySet()) {
                System.out.println("Category: " + entry.getKey() + ", Amount: " + entry.getValue());
            }

            // Open PieChartExample with income and expense breakdown by category
            PieChartExample pieChartExample = new PieChartExample(totalIncome, expenseCategories, userId);
            pieChartExample.show(primaryStage);  // Pass the current stage to the pie chart

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
