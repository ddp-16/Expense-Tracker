import javafx.scene.Scene;
import javafx.scene.chart.PieChart;
import javafx.scene.control.Button;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import javafx.geometry.Pos;

import java.util.Map;

public class PieChartExample {
    private double totalIncome;
    private Map<String, Double> expenseCategories;  // Map for expense categories and amounts
    private int userId;

    public PieChartExample(double totalIncome, Map<String, Double> expenseCategories, int userId) {
        this.totalIncome = totalIncome;
        this.expenseCategories = expenseCategories;
        this.userId = userId;  // Capture the userId to use in navigation
    }

    public void show(Stage stage) {
        stage.setTitle("Income and Expense Pie Chart");
        PieChart pieChart = new PieChart();

        // Add Income slice
        if (totalIncome > 0) {
            pieChart.getData().add(new PieChart.Data("Income", totalIncome));
        } else {
            pieChart.getData().add(new PieChart.Data("Income", 0));  // Default to 0 if no income
        }

        // Add Expense categories to the pie chart
        if (!expenseCategories.isEmpty()) {
            for (Map.Entry<String, Double> entry : expenseCategories.entrySet()) {
                String category = entry.getKey();
                double amount = entry.getValue();

                // Ensure the amount is positive to avoid errors
                if (amount > 0) {
                    pieChart.getData().add(new PieChart.Data(category, 2*amount));
                }
            }
        } else {
            // Add a default if there are no expenses
            pieChart.getData().add(new PieChart.Data("No Expenses", 0));
        }

        // Set up listener to change label colors
        for (PieChart.Data data : pieChart.getData()) {
            data.nodeProperty().addListener((obs, oldNode, newNode) -> {
                if (newNode != null) {
                    // Ensure the label is styled as soon as the node is created
                    newNode.lookup(".chart-label").setStyle("-fx-text-fill: white;");  // Change the label color
                }
            });
        }

        // Create a horizontal navbar
        HBox navbar = new HBox(10);
        navbar.setAlignment(Pos.TOP_LEFT);
        navbar.setStyle("-fx-background-color: darkorange; ");

        Button homeButton = new Button("Home");
        Button pieChartButton = new Button("Pie Chart");
        Button logoutButton = new Button("Logout");

        navbar.getChildren().addAll(homeButton, pieChartButton, logoutButton);

        // Navbar button actions
        homeButton.setOnAction(e -> {
            // Assuming the openTrackerPage method is part of the Main class for navigation
            Main mainApp = new Main();
            mainApp.openTrackerPage(stage, userId);  // Navigate back to the home page
        });

        pieChartButton.setOnAction(e -> show(stage));  // Refreshes the current pie chart page

        logoutButton.setOnAction(e -> {
            stage.close();  // Close the application
            System.out.println("User logged out.");
        });

        // Add pie chart and navbar to layout
        VBox vbox = new VBox(10, navbar, pieChart);
        Scene scene = new Scene(vbox, 1000, 600);
        scene.getStylesheets().add("style.css");

        // Set the background color to black for better contrast
        vbox.setStyle("-fx-background-color: white;");

        stage.setScene(scene);
        stage.show();
    }
}
