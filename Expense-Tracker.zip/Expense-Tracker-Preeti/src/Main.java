import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class Main extends Application {

    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("Income & Expense Tracker");

        // Create login form
        Label userLabel = new Label("Username:");
        TextField usernameField = new TextField();
        usernameField.setMaxWidth(300);
        Label passLabel = new Label("Password:");
        PasswordField passwordField = new PasswordField();
        passwordField.setMaxWidth(300);

        Button loginButton = new Button("Login");
        Button signUpButton = new Button("Sign Up");

        // Create a horizontal layout for the buttons
        HBox buttonBox = new HBox(10, loginButton, signUpButton);
        buttonBox.setAlignment(Pos.CENTER); // Center align the buttons

        // Layout for login screen
        VBox vbox = new VBox(10, userLabel, usernameField, passLabel, passwordField, buttonBox);
        vbox.setAlignment(Pos.CENTER);
        vbox.setStyle("-fx-padding: 20;");

        Scene scene = new Scene(vbox, 800, 600);  // Set initial stage size
        scene.getStylesheets().add("style.css");  // Attach CSS

        // Login button action
        loginButton.setOnAction(e -> {
            String username = usernameField.getText();
            String password = passwordField.getText();

            UserAuth auth = new UserAuth();
            if (auth.login(username, password)) {
                int userId = auth.getUserId(username); // Get user ID
                System.out.println("Login successful");
                openTrackerPage(primaryStage, userId); // Pass userId
            } else {
                System.out.println("Login failed");
            }
        });

        // Sign Up button action
        signUpButton.setOnAction(e -> {
            String username = usernameField.getText();
            String password = passwordField.getText();

            UserAuth auth = new UserAuth();
            if (auth.signUp(username, password)) {
                int userId = auth.getUserId(username); // Get user ID
                System.out.println("Signup successful");
                openTrackerPage(primaryStage, userId); // Pass userId
            } else {
                System.out.println("Signup failed");
            }
        });

        primaryStage.setScene(scene);
        primaryStage.show();
    }

    // Method to open the tracker page after login
    public void openTrackerPage(Stage primaryStage, int userId) {
        IncomeExpenseTracker tracker = new IncomeExpenseTracker(userId);

        // Create a horizontal navbar
        HBox navbar = new HBox(10);
        navbar.setAlignment(Pos.TOP_LEFT);
        navbar.setStyle("-fx-background-color: darkorange; "); // Set navbar background to black

        Button homeButton = new Button("Home");
        Button pieChartButton = new Button("Pie Chart");
        Button logoutButton = new Button("Logout");

        navbar.getChildren().addAll(homeButton, pieChartButton, logoutButton);

        // Create a simple user interface for adding income/expense and showing summary
        VBox vbox = new VBox(10);
        Label titleLabel = new Label("Income and Expense Tracker");
        titleLabel.setStyle("-fx-text-fill: white;"); // Set title color to white

        // Income input
        TextField incomeField = new TextField();
        incomeField.setPromptText("Enter income amount");
        incomeField.setMaxWidth(300);
        TextField incomeDescField = new TextField();
        incomeDescField.setPromptText("Enter income description");
        Button addIncomeButton = new Button("Add Income");
        incomeDescField.setMaxWidth(300);

        // Expense input
        TextField expenseField = new TextField();
        expenseField.setPromptText("Enter expense amount");
        expenseField.setMaxWidth(300);


        // Expense description input
        TextField expenseDescField = new TextField();
        expenseDescField.setPromptText("Enter expense description");
        expenseDescField.setMaxWidth(300);
        // Drop-down for expense categories
        ComboBox<String> expenseCategoryComboBox = new ComboBox<>();
        expenseCategoryComboBox.getItems().addAll("Food", "Transportation", "Entertainment","Shopping","Vacation","Utilities", "Other");
        expenseCategoryComboBox.setPromptText("Select expense category");
        expenseCategoryComboBox.setMaxWidth(300);

        Button addExpenseButton = new Button("Add Expense");

        // Summary button
        Button showSummaryButton = new Button("Show Summary");

        // Actions for adding income
        addIncomeButton.setOnAction(e -> {
            double amount = Double.parseDouble(incomeField.getText());
            String description = incomeDescField.getText();
            tracker.addIncome(amount, description);
            incomeField.clear();
            incomeDescField.clear();
        });

        // Actions for adding expense
        addExpenseButton.setOnAction(e -> {
            double amount = Double.parseDouble(expenseField.getText());
            String category = expenseCategoryComboBox.getValue();  // Get selected category from ComboBox
            String description = expenseDescField.getText();

            if (category != null) {
                description = category + " - " + description;  // Combine category and description
            }

            tracker.addExpense(amount, description);
            expenseField.clear();
            expenseDescField.clear();
            expenseCategoryComboBox.setValue(null);  // Reset the ComboBox
        });

        showSummaryButton.setOnAction(e -> tracker.showSummary(primaryStage));

        // Navbar button actions
        homeButton.setOnAction(e -> openTrackerPage(primaryStage, userId));  // Reloads the home page
        pieChartButton.setOnAction(e -> tracker.showSummary(primaryStage));  // Shows the pie chart
        logoutButton.setOnAction(e -> {
            primaryStage.close();  // Closes the application on logout
            System.out.println("User logged out.");
        });

        // Add all components to the layout, including the navbar
        vbox.getChildren().addAll(navbar, titleLabel, incomeField, incomeDescField, addIncomeButton,
                expenseField, expenseCategoryComboBox, expenseDescField, addExpenseButton,
                showSummaryButton);
        vbox.setAlignment(Pos.CENTER);
        vbox.setStyle("-fx-background-color: black;"); // Set background color to black for the tracker page

        Scene trackerScene = new Scene(vbox, 1000, 600);
        trackerScene.getStylesheets().add("style.css");  // Attach CSS
        primaryStage.setScene(trackerScene);
    }

    public static void main(String[] args) {
        launch(args);
    }
}
